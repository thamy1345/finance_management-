# Laravel Docker Template (reusable across projects)

Two layers:

1. **`base/`** — a shared image (`laravel-base:8.3`) with PHP, Apache, all
   common extensions, and prod-tuned config. Build this **once**, push it to
   a registry, and reuse it for every Laravel project.
2. **`template/`** — the slim, per-project files (`Dockerfile`,
   `docker-compose.yml`, `.dockerignore`, `.env.docker.example`) that extend
   the base image. Copy these into each new project via `scaffold.sh`.

```
laravel-docker-template/
├── base/
│   ├── Dockerfile              # build once → laravel-base:8.3
│   ├── apache/000-default.conf
│   ├── php/production.ini
│   └── entrypoint.sh
├── template/
│   ├── Dockerfile              # per-project, FROM laravel-base:8.3
│   ├── docker-compose.yml
│   ├── .dockerignore
│   └── .env.docker.example
├── scaffold.sh                 # copies template/ into a new project
└── README.md
```

## One-time setup

Build and push the base image (do this once, and again only when you need
to bump PHP version, add a system-wide extension, or change Apache/php.ini
defaults):

```bash
cd base
docker build -t your-registry/laravel-base:8.3 .
docker push your-registry/laravel-base:8.3
```

Replace `your-registry` with your actual registry (Docker Hub, GHCR, ECR,
etc.) — or just build it locally (`docker build -t laravel-base:8.3 .`) if
you're only running on one machine and don't need to push anywhere.

## Every time you start a new Laravel project

```bash
./scaffold.sh /path/to/new-project my-project-name
```

This copies the per-project files in and fills in the project name. Then:

1. Point `Dockerfile`'s `FROM your-registry/laravel-base:8.3` line at wherever
   you pushed the base image.
2. Confirm the frontend stage matches the project's bundler (Vite by
   default — comments in the Dockerfile explain how to adjust for Mix or
   no bundler).
3. Merge `.env.docker.example` into the project's `.env`, fill in `APP_KEY`
   and real DB passwords.
4. `docker compose build && docker compose up -d`

## Why split it this way

- **Base image** rebuilds are rare (PHP version bumps, new system
  extensions) — most projects never trigger this.
- **Per-project Dockerfile** stays small: just Composer install, frontend
  build, and copying your app code onto the shared base.
- Every project builds *faster* because the heavy layer (system packages +
  PHP extension compilation) is already baked into the base image and
  cached in the registry — Docker doesn't recompile `gd`/`redis`/etc. for
  every single project.
- Updating Apache or PHP config for all projects at once means editing
  `base/`, rebuilding, and repushing — not hunting through N project repos.

## Keeping this template itself reusable

Put this whole `laravel-docker-template/` folder in its own git repo. When
you start a new project, either `git clone` it somewhere and run
`scaffold.sh`, or vendor it in as a git submodule if you want version
tracking across projects.
