#!/bin/sh
set -e

cd /var/www/html

# Generate APP_KEY only if missing (won't overwrite an existing one)
if [ -z "$APP_KEY" ]; then
    echo "WARNING: APP_KEY is not set. Set it in your environment/secret store."
fi

echo "Caching Laravel config/routes/views..."
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache

# Only the deploy/release step should set RUN_MIGRATIONS=true —
# not every replica on every restart, to avoid concurrent migration races.
if [ "$RUN_MIGRATIONS" = "true" ]; then
    echo "Running migrations..."
    php artisan migrate --force
fi

exec "$@"
