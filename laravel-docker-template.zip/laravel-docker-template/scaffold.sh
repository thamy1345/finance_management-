#!/bin/sh
# Usage: ./scaffold.sh /path/to/your/laravel/project [project-name]
#
# Copies the Docker template (Dockerfile, docker-compose.yml, .dockerignore,
# .env.docker.example) into a Laravel project and substitutes the project
# name into docker-compose.yml and the env example.

set -e

TARGET_DIR="$1"
PROJECT_NAME="${2:-$(basename "$(cd "$TARGET_DIR" && pwd)")}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -z "$TARGET_DIR" ]; then
    echo "Usage: $0 /path/to/your/laravel/project [project-name]"
    exit 1
fi

if [ ! -f "$TARGET_DIR/artisan" ]; then
    echo "Error: $TARGET_DIR doesn't look like a Laravel project (no 'artisan' file found)."
    exit 1
fi

echo "Scaffolding Docker setup for '$PROJECT_NAME' in $TARGET_DIR ..."

cp "$SCRIPT_DIR/template/Dockerfile" "$TARGET_DIR/Dockerfile"
cp "$SCRIPT_DIR/template/docker-compose.yml" "$TARGET_DIR/docker-compose.yml"
cp "$SCRIPT_DIR/template/.dockerignore" "$TARGET_DIR/.dockerignore"
cp "$SCRIPT_DIR/template/.env.docker.example" "$TARGET_DIR/.env.docker.example"

# Substitute the project name placeholder
sed -i.bak "s/__PROJECT_NAME__/$PROJECT_NAME/g" "$TARGET_DIR/docker-compose.yml"
sed -i.bak "s/__PROJECT_NAME__/$PROJECT_NAME/g" "$TARGET_DIR/.env.docker.example"
rm -f "$TARGET_DIR/docker-compose.yml.bak" "$TARGET_DIR/.env.docker.example.bak"

cat <<EOF

Done. Next steps:

1. Open $TARGET_DIR/Dockerfile and set the base image tag:
       FROM your-registry/laravel-base:8.3 AS runtime
   (build & push base/Dockerfile from this template once, if you haven't yet)

2. Check whether this project uses Vite, Mix, or no bundler — adjust the
   'frontend' stage in Dockerfile if needed.

3. Merge $TARGET_DIR/.env.docker.example into your .env, and set:
       APP_KEY   -> php artisan key:generate --show
       DB_PASSWORD / DB_ROOT_PASSWORD -> real secrets

4. Build and run:
       cd $TARGET_DIR
       docker compose build
       docker compose up -d

EOF
